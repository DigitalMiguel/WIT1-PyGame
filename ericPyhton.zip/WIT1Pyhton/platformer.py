import pygame
from gameObjects import *
# import random

running = True
FPS = 60
BLACK = (0,0,0)
WHITE = (255,255,255)
RED = (240,10,10)
BACKGROUND_COLOR = (240,10,10)
YELLOW = (255,255,0)
BLUE = (0,0,255)

playerX = 150
playerY = 150

    # start up pygame
pygame.init()
    # start up sound module f/ pygame
pygame.mixer.init()
    # set up the screenn for our game
screen = pygame.display.set_mode((640,640))
    # keeps track of game clock
clock = pygame.time.Clock()

start_ticks=pygame.time.get_ticks()
timer = 0


player = Player(screen)

all_sprites = pygame.sprite.Group()

all_sprites.add(player)


walls = pygame.sprite.Group()


#layout
layout =   ["BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB     BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
            "B                             BBBBBBB                                                                                       BBBBBBBBB                             BBBBBBBBB                                BB     BB                                                                                            B",
            "B                                                                                                                             BBBBB                                BBBBBB                                  BB     BB                                                                                            B",
            "B                             BBBBBBB             BBBBB                                                                      BBB                                    BBB                                    BB     BB                                                                           BBBB   B   B   B B",
            "BBBB              BBBB          BYB      BBBBB     BBYB      BBB                             BBB                BBB            BB                                    BB                                    BB     BB                                                                           B      B   BB  B B",
            "BYBB              BYYB        BBBBBBB              BBBB      BYB                             BYB                BYB           BB                                     BB                                    BB     BB                                                                           BBB    B   B B B B",
            "BBB     BBB       BBBB         BYB                 BYBB      BBB                BBB          BBB                BBB           BB                                    BBB                                                                                                                        B      B   B  BB B",
            "B       BYB                   BBBBBBB              BBBB                         BYB                                           BB                                     BB                                    BB     BB                                                                           B      B   B   B B",
            "B       BBB                   BBBBBBB              BBYB              BBB        BBB                                           BB                                     BB                     BB             BB     BB                                                                                            B",
            "B                               BBYB               BBBB              BYB                                                     BBBB                                   BB                      BB             BB     BB                                                                                            B",
            "B                            BBBBBBBBB             BYBB              BBB                                                                                                                    BB             BB     BB                                                                          BBBBBBB  BBBBBBBBBB",
            "B                             BBBBBBB              BYBB                                       BBB                            BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB     BBBBB            BB             BB     BB                                                                          BBBBBBBB BBBBBBBBBB",
            "B                              BYB                BBBBB                                                              BBB       BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB     BBYBBB           BB             BB     BB                                                                   BB     BBBBBBBB BBBBBBBBBB",
            "B                             BBBBBBB                                                                                BBB          BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB    BBBBBB            BB             BB     BB                                                             BB    BB     BBBBBBBB BBBBBBBBBB",
            "B                                                                                                                    BYB          BBBBBBBBBBBBBBBBBBBBBBYBBBBBBBBBBBBB    BBYBBBBB          BB             BB     BB                                     BB                BB    BB    BB     BBBBBBBB BBBBBBBBBB",
            "B                                                  BBB                                                       BBB     BYB        BBBBBBBBBBBBBBBBBBBBBBBBBYYBBBBBBBBBBB     BBBYB            BB                    BB                 BB                  BB                BB    BB    BB     BBBBBBBV VWWWBBBBBB",
            "B                                                  BYB                                             BBB       BYB     BBB        BBBBBBBBBBBYYYYYYYYYYYYYYYYYYYBBBBBBBB    BBBBBBB           BB                                       BB         BB       BB          BB    BB    BB    BB     BBBBBBBWVWWWWBBBBBB",
            "B                           BBB     BBB  BBB   BBB BBB      BBB                 BBB                BYB       BYB     BBB         BBBBBBBBBBBBBBBBBBBBBBBBYYBBBBBBBB        BBYBB            BB             BB                BB      BB         BB       BB          BB    BB    BB    BB     BBBBBBBWWWWWWBBBBBB",
            "BBBBBBB     BBBBBBB         BYB     BYB  BYB   BYB BYB      BYB        BBB      BYB      BBB       BBB       BBB     BYB       BBBBBBBBBBBBBBBBBBBBBBBBBYBBBBBBBBBBBBB     BBYBBBB          BB             BB     BB         BB      BB         BB       BB          BB    BB    BB    BB     BBBBBBBWWWWWWBBBBBB",
            "BBYBYBB     BBYBYBB         BBB     BBB  BBB   BBB BBB      BBB        BBB      BBB      BYB       BBB       BBB     BBB       BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB   BBBBBBBBBB        BBB            BB     BB         BB      BB         BB       BB          BB    BB    BB    BB     BBBBBBBWWWWWWBBBBBB" ]

x = 0
y = 0
size = 32
for row in layout:
    for col in row:
        if col == "B":
            walls.add( Wall((BLACK),x,y,size) )
            x = x + size

        if col == "Y":
            walls.add( Wall((YELLOW),x,y,size) )
            x = x + size

        if col == "W":
            walls.add( Wall((WHITE),x,y,size) )
            x = x + size

        if col == "I":
            walls.add( InvisibleWall((BACKGROUND_COLOR),x,y,size) )
            x = x + size

        if col == "T":
            walls.add( TrickWall((BLACK),x,y,size) )
            x = x + size

        if col == "V":
            walls.add( VictoryWall((WHITE),x,y,size) )
            x = x + size

        if col == " ":
            x = x + size
    y = y + size
    x = 0

player.localWalls = walls
print()


while running :

    # game events happen here
    clock.tick(FPS)

    timer = (pygame.time.get_ticks() - start_ticks)/1000
    player.timer = timer
    # Wipe screen
    screen.fill(RED)

    # process input
    for event in pygame.event.get():
        # Check for exiting out of window
        if event.type == pygame.QUIT :
            running = False

            #process controls
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player.goLeft()
            if event.key == pygame.K_RIGHT:
                player.goRight()
            if event.key == pygame.K_UP:
                player.jump()

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                player.stop()
            if event.key == pygame.K_RIGHT:
                player.stop()

    all_sprites.update()

    all_sprites.draw(screen)

    walls.draw(screen)
    # for wall in walls:
    #     pygame.draw.rect(screen, WHITE, wall.rect)
    # Display new screen
    pygame.display.flip()

    # end of while loop

print(timer)

pygame.quit()
