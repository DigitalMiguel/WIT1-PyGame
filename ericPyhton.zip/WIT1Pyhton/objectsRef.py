class TestingObject:
    var = "Hello"

    def function(self):
        print("Hello I'm just a function")

# class Vehicle:
#     type = "None"
#     cupholders = False
#     numSeats = 1
#     engine = True
#
#     def getType(self):
#         return self.type
#
#     def setType(self, name):
#         self.type = name
#
#     def getSeats(self):
#         return self.numSeats
#
#     def setSeats(self, num):
#         self.numSeats = num

class Table:
    name = "Hubert"
    type = "School Desk"
    numLegs = 4


    def getName(self):
        return self.name

    def setName(self, name):
        self.name = name


    def getType(self):
        return self.type

    def setType(self, type):
        self.type = type

    def getLegs(self):
        return self.numLegs

    def setLegs(self, num):
        self.numLegs = num
T1 = Table()
print(self.name)
print(self.type)
print(self.numLegs)







# myObject = TestingObject()
#
# myObject.function()




# vehicle1 = Vehicle()
#
# vehicle1.setSeats(45)
#
# vehicle1.setType(input())
#
# print(vehicle1.getSeats())
